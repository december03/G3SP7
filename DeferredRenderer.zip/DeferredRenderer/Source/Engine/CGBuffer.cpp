#include "stdafx.h"
#include "GBuffer.h"
