#include "stdafx.h"
#include "EnvironmentLight.h"
